﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkWithDatabase
{
    public partial class Form3 : Form
    {
        public int id;
        public Form3(int id)
        {
            InitializeComponent();
            this.id = id;
        }
        private Boolean IsCorrect()
        {
            if (this.textBox1.Text == "")
            {
                MessageBox.Show("* field empty. Fill it", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            try
            {
                id = Convert.ToInt32(this.textBox1.Text);
                return true;
            }
            catch (FormatException fe)
            {
                MessageBox.Show("Wrong ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (IsCorrect()) this.Close();
        }
    }
}
