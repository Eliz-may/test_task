﻿using System;
using System.Windows.Forms;

namespace WorkWithDatabase
{
    public partial class Form2 : Form
    {
       public Person person;
        public Form2(Person p)
        {
            InitializeComponent();
            this.person = new Person();
            this.City.Text = null;
            this.Email.Text = null;
        }
        private void Send_Click(object sender, EventArgs e)
        {
            if (IsCorrect()) this.Close();
        }
        private Boolean IsCorrect()
        {
            if (this.FIO.Text == "" || this.Number.Text == "")
            {
                MessageBox.Show("* field empty. Fill it", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            this.person.Fio = this.FIO.Text;
            this.person.City = this.City.Text;
            this.person.Phone = this.Number.Text;
            this.person.Email = this.Email.Text;
            try
            {
                this.person.Birth = DateTime.Parse(this.Birth.Text);
            }
            catch (Exception error)
            {
                MessageBox.Show("Wrong date format", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
    }
}
