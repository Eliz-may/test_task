﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows.Forms;

namespace WorkWithDatabase
{
    public partial class Form2 : Form
    {
       public Person person;
        public Form2(Person p)
        {
            InitializeComponent();
            this.person = new Person();
            this.City.Text = null;
            this.Email.Text = null;
        }
        private void Send_Click(object sender, EventArgs e)
        {
            if (IsCorrect()) this.Close();
        }

        /**
         * check correctness of data and return person data
         */
        private Boolean IsCorrect()
        {
            List<String> phone;
            if (this.FIO.Text == "" || this.Number.Text == "")
            {
                MessageBox.Show("* field empty. Fill it", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            phone = new List<String>();
            phone.Add(this.Number.Text);
            phone.Add(this.Second.Text);
            phone.Add(this.Third.Text);
            this.person.Fio = this.FIO.Text;
            this.person.City = this.City.Text;
            this.person.Phone = phone;
            this.person.Email = this.Email.Text;
            this.person.Phone.Add(this.Second.Text);
            this.person.Phone.Add(this.Third.Text);
            try
            {
                this.person.Birth = DateTime.Parse(this.Birth.Text);
            }
            catch (Exception error)
            {
                MessageBox.Show("Wrong date format", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
    }
}
