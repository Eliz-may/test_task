﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SQLite;
using System.IO;

namespace WorkWithDatabase
{
    public partial class Form1 : Form
    {
        bool isOpen;
        public Form1()
        {
            InitializeComponent();
            label1.Text = "Open database..";
        }
        SQLiteConnection connection;
        private void openDatabase_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                String fileName = openFileDialog1.FileName;
                connection = new SQLiteConnection();
                try
                {
                    connection.ConnectionString = "Data Source=\"" + fileName + "\"";
                    isOpen = true;
                    label1.Text = "Database open: " + fileName;
                    loadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Couldn't open database");
                }
            }
        }
        private void loadData()
        {
            if (isOpen)
            {
                SQLiteCommand cmd = new SQLiteCommand();
                cmd.Connection = connection;
                connection.Open();
                cmd.CommandText = "SELECT P.*, N.Number FROM Person as P inner join Person_Number as  P_N on P.ID=P_N.person_id inner join PhoneNumber as N on P_N.number_id=N.ID ORDER BY P.ID;";
                SQLiteDataReader sdr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(sdr);
                sdr.Close();
                connection.Close();
                dataGridView1.DataSource = dt;
            }
        }
        Person person = new Person();
        private void Add_Click(object sender, EventArgs e)
        {
            if (!isOpen)
            {
                MessageBox.Show("Open database!");
            }
            else
            {
                int count = CountNumbers();
                Form2 f2 = new Form2(person);
                person = f2.person;
                f2.ShowDialog();
                int id = CountPerson() + 1;
                if (InsertPerson(id))
                {
                    InsertPhoneNumber(count);
                    InsertPerson_Number(id, count);
                }
            }
            loadData();
        }
        private Boolean InsertPerson(int id)
        {
            try
            {
                connection.Open();
                String birth = person.Birth.ToString("dd-MM-yyyy");
                SQLiteCommand cmd = new SQLiteCommand();
                cmd.Connection = connection;
                cmd.CommandText = String.Format("INSERT INTO Person(ID, FIO, DateOfBirth, City, email) VALUES({0}, '{1}', '{2}', '{3}', '{4}')", id, person.Fio, birth, person.City, person.Email);
                cmd.ExecuteNonQuery();
                connection.Close();
                return true;
            }
            catch (SQLiteException)
            {
                MessageBox.Show("Wrong ID! Id sould be unique");
                connection.Close();
                return false;
            }
        }
        private void InsertPhoneNumber(int count)
        {
            connection.Open();
            SQLiteCommand cmd = new SQLiteCommand();
            cmd.Connection = connection;
            cmd.CommandText = String.Format("INSERT INTO PhoneNumber(ID, Number) VALUES({0}, '{1}')", (count + 1001), person.Phone);
            cmd.ExecuteNonQuery();
            connection.Close();
        }
        private void InsertPerson_Number(int id, int count)
        {
            connection.Open();
            SQLiteCommand cmd = new SQLiteCommand();
            cmd.Connection = connection;
            cmd.CommandText = String.Format("INSERT INTO Person_Number(person_id, number_id) VALUES({0},{1})", id, count + 1001);
            cmd.ExecuteNonQuery();
            connection.Close();
        }
        private void edit_Click(object sender, EventArgs e)
        {
            if (!isOpen)
            {
                MessageBox.Show("Open database!");
            }
            else
            {
                int id = 0;
                Form3 f3 = new Form3(id);
                f3.ShowDialog();
                id = f3.id;
                if (id != 0)
                {
                    Form2 f2 = new Form2(person);
                    person = f2.person;
                    f2.ShowDialog();
                    String birth = person.Birth.ToString("dd-MM-yyyy");
                    connection.Open();
                    SQLiteCommand cmd = new SQLiteCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = String.Format("UPDATE Person SET FIO = '{0}', DateOfBirth = '{1}', City = '{2}', email = '{3}' WHERE ID = '{4}';", person.Fio, birth, person.City, person.Email, id);
                    cmd.ExecuteNonQuery();
                    connection.Close();
                    editNumber(id);
                }
            }
            loadData();
        }
        private void editNumber(int id)
        {
            int idNumber = 0;
            String cmdt = String.Format("select N.ID from PhoneNumber as N INNER join Person_Number as P_N on N.ID = P_N.number_id where person_id = {0}", id);
            using (SQLiteCommand cmdCount = new SQLiteCommand(cmdt, connection))
            {
                connection.Open();
                idNumber = Convert.ToInt32(cmdCount.ExecuteScalar());
                connection.Close();
            }
            connection.Open();
            SQLiteCommand cmd = new SQLiteCommand();
            cmd.Connection = connection;
            cmd.CommandText = String.Format("UPDATE PhoneNumber SET Number = '{0}';", person.Phone);
            cmd.ExecuteNonQuery();
            connection.Close();
        }

        private void delete_Click(object sender, EventArgs e)
        {
            if (!isOpen)
            {
                MessageBox.Show("Open database!");
            }
            else
            {
                int id = 0;
                Form3 f3 = new Form3(id);
                f3.ShowDialog();
                id = f3.id;
                deletePerson(id);
                deletePerson_Number(id);
            }
            loadData();
        }
        private void deletePerson(int id)
        {
            connection.Open();
            SQLiteCommand cmd = new SQLiteCommand();
            cmd.Connection = connection;
            cmd.CommandText = String.Format("DELETE FROM Person_Number WHERE person_id = {0};", id);
            cmd.ExecuteNonQuery();
            connection.Close();
        }
        private void deletePerson_Number(int id)
        {
            connection.Open();
            SQLiteCommand cmd = new SQLiteCommand();
            cmd.Connection = connection;
            cmd.CommandText = String.Format("DELETE FROM Person WHERE ID = {0};", id);
            cmd.ExecuteNonQuery();
            connection.Close();
        }
        private int CountNumbers()
        {
            int count = 0;
            String cmdt = "SELECT COUNT(ID) FROM PhoneNumber";
            using (SQLiteCommand cmdCount = new SQLiteCommand(cmdt, connection))
            {
                connection.Open();
                count = Convert.ToInt32(cmdCount.ExecuteScalar());
                connection.Close();
            }
            return count;
        }

        private int CountPerson()
        {
            int count = 0;
            String cmdt = "SELECT COUNT(ID) FROM Person";
            using (SQLiteCommand cmdCount = new SQLiteCommand(cmdt, connection))
            {
                connection.Open();
                count = Convert.ToInt32(cmdCount.ExecuteScalar());
                connection.Close();
            }
            return count;
        }

        private void OpenSkript_Click(object sender, EventArgs e)
        {
            if (!isOpen)
            {
                MessageBox.Show("Open database! (empty.db)");
            }
            else
            {
                if (openFileDialog2.ShowDialog() == DialogResult.OK)
                {
                    String fileName = openFileDialog2.FileName;
                    using (System.IO.FileStream fstream = File.OpenRead(fileName))
                    {
                        byte[] array = new byte[fstream.Length];
                        fstream.Read(array, 0, array.Length);
                        string script = System.Text.Encoding.Default.GetString(array);

                        connection.Open();
                        SQLiteCommand cmd = new SQLiteCommand();
                        cmd.Connection = connection;
                        cmd.CommandText = script;
                        cmd.ExecuteNonQuery();
                        connection.Close();
                        loadData();
                    }
                }
            }
        }
    }
}
