﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SQLite;
using System.IO;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace WorkWithDatabase
{
    public partial class Form1 : Form
    {
        bool isOpen;
        Person person = new Person();
        public Form1()
        {
            InitializeComponent();
            label1.Text = "Open database..";
        }
        SQLiteConnection connection;
        /**
         * open database.
         */
        private void openDatabase_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                String fileName = openFileDialog1.FileName;
                connection = new SQLiteConnection();
                try
                {
                    connection.ConnectionString = "Data Source=\"" + fileName + "\"";
                    isOpen = true;
                    label1.Text = "Database open: " + fileName;
                    loadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Couldn't open database");
                }
            }
        }
        /**
         * return database query and load data in dataGridView.
         */
        private void loadData()
        {
            if (isOpen)
            {
                SQLiteCommand cmd = new SQLiteCommand();
                cmd.Connection = connection;
                connection.Open();
                cmd.CommandText = "SELECT P.*, N.Number FROM Person as P inner join Person_Number as  P_N on P.ID=P_N.person_id inner join PhoneNumber as N on P_N.number_id=N.ID ORDER BY P.ID;";
                SQLiteDataReader sdr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(sdr);
                sdr.Close();
                connection.Close();
                dataGridView1.DataSource = dt;
            }
        }
        /**
         * check if database is open, call form2 to read data and call method to fill tables.
         */
        private void Add_Click(object sender, EventArgs e)
        {
            if (!isOpen)
            {
                MessageBox.Show("Open database!");
            }
            else
            {
                int count = CountNumbers();
                Form2 f2 = new Form2(person);
                person = f2.person;
                f2.ShowDialog();
                int id = CountPerson() + 1;
                InsertPerson(id);
                InsertPhoneNumber(count,id);
            }
            loadData();
        }
        /**
         * fill table Person
         */
        private void InsertPerson(int id)
        {
             connection.Open();
             String birth = person.Birth.ToString("dd-MM-yyyy");
             SQLiteCommand cmd = new SQLiteCommand();
             cmd.Connection = connection;
             cmd.CommandText = String.Format("INSERT INTO Person(ID, FIO, DateOfBirth, City, email) VALUES({0}, '{1}', '{2}', '{3}', '{4}')", id, person.Fio, birth, person.City, person.Email);
             cmd.ExecuteNonQuery();
             connection.Close();
        }
        /**
         * fill table PhoneNumber with person's numbers
         */
        private void InsertPhoneNumber(int count,int id)
        {
            int idPhone = count + 1001;
            connection.Open();
            SQLiteCommand cmd = new SQLiteCommand();
            cmd.Connection = connection;
            cmd.CommandText = String.Format("INSERT INTO PhoneNumber(ID, Number) VALUES({0}, '{1}'); INSERT INTO Person_Number(person_id, number_id) VALUES({2}, '{3}')", idPhone, person.Phone[0].ToString(), id, idPhone);
            cmd.ExecuteNonQuery();
            connection.Close();
            if (person.Phone[1] != "")
            {
                idPhone++;
                connection.Open();
                cmd.Connection = connection;
                cmd.CommandText = String.Format("INSERT INTO PhoneNumber(ID, Number) VALUES({0}, '{1}'); INSERT INTO Person_Number(person_id, number_id) VALUES({2}, '{3}')", idPhone, person.Phone[1].ToString(), id, idPhone);
                cmd.ExecuteNonQuery();
                connection.Close();
            }
            if (person.Phone[2] != "")
            {
                idPhone++;
                connection.Open();
                cmd.Connection = connection;
                cmd.CommandText = String.Format("INSERT INTO PhoneNumber(ID, Number) VALUES({0}, '{1}'); INSERT INTO Person_Number(person_id, number_id) VALUES({2}, '{3}')", idPhone, person.Phone[2].ToString(), id, idPhone);
                cmd.ExecuteNonQuery();
                connection.Close();
            }
        }
        /**
         * check if database open, ask user data and edit person.
         */
        private void edit_Click(object sender, EventArgs e)
        {
            if (!isOpen)
            {
                MessageBox.Show("Open database!");
            }
            else
            {
                int id = 0;
                Form3 f3 = new Form3(id);
                f3.ShowDialog();
                id = f3.id;
                if (id != 0)
                {
                    Form4 f4 = new Form4(person);
                    person = f4.person;
                    f4.ShowDialog();
                    String birth = person.Birth.ToString("dd-MM-yyyy");
                    connection.Open();
                    SQLiteCommand cmd = new SQLiteCommand();
                    cmd.Connection = connection;
                    cmd.CommandText = String.Format("UPDATE Person SET FIO = '{0}', DateOfBirth = '{1}', City = '{2}', email = '{3}' WHERE ID = '{4}';", person.Fio, birth, person.City, person.Email, id);
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            loadData();
        }
        /**
        * Replace old number phone with a new.
        */
        private void editNumber_Click(object sender, EventArgs e)
        {
            if (!isOpen)
            {
                MessageBox.Show("Open database!");
            }
            else
            {
                int id = 0;
                List<String> phoneNumb = new List<String>();
                Form3 f3 = new Form3(id);
                f3.ShowDialog();
                id = f3.id;
                if (id != 0)
                {
                    Form5 f5 = new Form5(phoneNumb);
                    phoneNumb = f5.phoneNumb;
                    f5.ShowDialog();
                    connection.Open();
                    SQLiteCommand cmd = new SQLiteCommand();
                    cmd.Connection = connection;
                    // cmd.CommandText = String.Format("update PhoneNumber SET Number = '{0}' where Number = '{1}'", phoneNumb[1], phoneNumb[0]);
                    cmd.CommandText = String.Format("update PhoneNumber SET Number = '{0}' where ID = (select  N.ID from PhoneNumber as N INNER join Person_Number as P_N on N.ID = P_N.number_id where person_id = {1} and Number = '{2}')", phoneNumb[1], id, phoneNumb[0]);
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
                loadData();
            }
        }
        /**
         * check if database open, ask user id of person and delete this person.
         */
        private void delete_Click(object sender, EventArgs e)
        {
            if (!isOpen)
            {
                MessageBox.Show("Open database!");
            }
            else
            {
                int id = 0;
                Form3 f3 = new Form3(id);
                f3.ShowDialog();
                id = f3.id;
                deletePerson(id);
                deletePerson_Number(id);
            }
            loadData();
        }
        /**
         * delete needed rows in table Person
         */
        private void deletePerson(int id)
        {
            connection.Open();
            SQLiteCommand cmd = new SQLiteCommand();
            cmd.Connection = connection;
            cmd.CommandText = String.Format("DELETE FROM Person_Number WHERE person_id = {0};", id);
            cmd.ExecuteNonQuery();
            connection.Close();
        }
        /**
         * delete needed rows in table Person_Number
         */
        private void deletePerson_Number(int id)
        {
            connection.Open();
            SQLiteCommand cmd = new SQLiteCommand();
            cmd.Connection = connection;
            cmd.CommandText = String.Format("DELETE FROM Person WHERE ID = {0};", id);
            cmd.ExecuteNonQuery();
            connection.Close();
        }
        /**
         * Query to database. Return count of phone numbers.
         */
        private int CountNumbers()
        {
            int count = 0;
            String cmdt = "SELECT COUNT(ID) FROM PhoneNumber";
            using (SQLiteCommand cmdCount = new SQLiteCommand(cmdt, connection))
            {
                connection.Open();
                count = Convert.ToInt32(cmdCount.ExecuteScalar());
                connection.Close();
            }
            return count;
        }
        /**
         * Query to database. Return count of person.
         */
        private int CountPerson()
        {
            int count = 0;
            String cmdt = "SELECT COUNT(ID) FROM Person";
            using (SQLiteCommand cmdCount = new SQLiteCommand(cmdt, connection))
            {
                connection.Open();
                count = Convert.ToInt32(cmdCount.ExecuteScalar());
                connection.Close();
            }
            return count;
        }
        /**
         * Open file, read data and send query to database to fill tables.
         */
        private void OpenSkript_Click(object sender, EventArgs e)
        {
            if (!isOpen)
            {
                MessageBox.Show("Open database! (empty.db)");
            }
            else
            {
                if (openFileDialog2.ShowDialog() == DialogResult.OK)
                {
                    String fileName = openFileDialog2.FileName;
                    using (FileStream fstream = File.OpenRead(fileName))
                    {
                        byte[] array = new byte[fstream.Length];
                        fstream.Read(array, 0, array.Length);
                        string script = System.Text.Encoding.Default.GetString(array);

                        connection.Open();
                        SQLiteCommand cmd = new SQLiteCommand();
                        cmd.Connection = connection;
                        cmd.CommandText = script;
                        cmd.ExecuteNonQuery();
                        connection.Close();
                        loadData();
                    }
                }
            }
        }
    }
}
