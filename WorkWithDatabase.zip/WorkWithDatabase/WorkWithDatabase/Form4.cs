﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkWithDatabase
{
    public partial class Form4 : Form
    {
        public Person person;
        public Form4(Person p)
        {
            InitializeComponent();
            this.person = new Person();
            this.City.Text = null;
            this.Email.Text = null;
        }
        /**
         * Check correctness of fields and record person data.
         */
        private Boolean IsCorrect()
        {
            if (this.FIO.Text == "")
            {
                MessageBox.Show("* field empty. Fill it", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            this.person.Fio = this.FIO.Text;
            this.person.City = this.City.Text;
            this.person.Email = this.Email.Text;
            try
            {
                this.person.Birth = DateTime.Parse(this.Birth.Text);
            }
            catch (Exception error)
            {
                MessageBox.Show("Wrong date format", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (IsCorrect()) this.Close();
        }
    }
}
