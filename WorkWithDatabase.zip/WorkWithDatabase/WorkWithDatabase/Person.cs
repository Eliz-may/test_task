﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkWithDatabase
{
    public class Person
    {
        private String fio;
        private String city;
        private List<String> phone;
        private DateTime birth;
        private String email;
        
        public String Fio
        {
            get { return fio; }
            set { fio = value; }
        }
        public String City
        {
            get { return city; }
            set { city = value; }
        }
        public List<String> Phone
        {
            get { return phone; }
            set { phone = value; }
        }
        public String Email
        {
            get { return email; }
            set { email = value; }
        }
        public DateTime Birth
        {
            get { return birth; }
            set { birth = value; }
        }
        public String write ()
        {
            return this.Fio + " " + this.Birth + " " + this.City + " " + this.Email;
        }   
    }
}
