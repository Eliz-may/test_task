﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkWithDatabase
{
    public partial class Form5 : Form
    { 
        public List<String> phoneNumb;
        public Form5(List<String> phoneNumb)
        {
            InitializeComponent();
            this.phoneNumb = phoneNumb;
        }
       
        /**
         * check correctness of data and return old and new number phone
         */
        private void button2_Click(object sender, EventArgs e)
        {
            if (this.textBox1.Text == "" || this.textBox2.Text == "")
            {
                MessageBox.Show("Field is empty. Fill it", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                phoneNumb.Add(this.textBox1.Text);
                phoneNumb.Add(this.textBox2.Text);
                this.Close();
            }
        }
    }
    
}
